C54x CSL Library Installation
(C) Copyright 2003 Texas Instruments Incorporated
All rights reserved worldwide.
-------------------------------------------------

Contents
--------
- ZIPFILE CONTENTS
- INSTALLATION INFORMATION
- BUGS FIXED FOR CURRENT VERSION
- CONTACTING TI


ZIPFILE CONTENTS
----------------
C54xxCSL.exe - Contains the installation program for the C54xx CSL Library
Readme.txt  - This file.
Releasenote.htm - Release note for version 2.31.00.7


INSTALLATION INFORMATION
------------------------
To run the TI C54xx CSL Library Installation, follow the directions below:

Windows 98, Windows NT, Windows 2000, Windows XP
1. Unzip the C54xxCSL.exe file to a temp directory
2. Double Click the file to launch the Install Shield Wizard
3. Answer all remaining questions presented in Install Shield dialog boxes

NOTES: 
1) If you DO NOT accept the software license agreement the library WILL NOT be installed. 
2) The default location to install the software is C:\Program Files\C54xxCSL, which will install the 
   libraries into C:\Program Files\C54xxCSL\lib and the header files into C:\Program Files\C54xxCSL\include.
   If CSL is installed over <CCS_Install_Dir>\bios\ , it will overwrite existing CSL
   version without taking any backup. So it is recommended that user take backup of 
   <CCS_Install_Dir>\bios\ folder before installing CSL there.

BUGS FIXED FOR CURRENT VERSION
------------------------------
SDSsq32475 - DMA_CH_RLDR_SUPPORT for 5403 and 5406 

SDSsq37450 - csl_mcbsphal.h - implementation errors(ABIS and SCLKME support).

SDSsq38041 - C54xx CSL : _HPI_GPIOSR_IOx_MK(n) macro returns incorrect value.

SDSsq34932 - Error in MCBSP_PCR_RMK() implementation.

SDSsq39525 - Dma example not working for channel 0. 

SDSsq35355 - Problem of far and near calls. 

CONTACTING TI
-------------
Texas Instruments Incorporated
Post Office Box 655303
Dallas, Texas  75265  USA

Phone: +1(972) 644-5580
Fax: +1(214) 480-7800
Internet: dsph@ti.com
World Wide Web: http://www.ti.com/sc/support
